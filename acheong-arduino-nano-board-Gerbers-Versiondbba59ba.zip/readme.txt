Project Name: arduino nano board
Project Version: #dbba59ba
Project Url: https://www.flux.ai/acheong/arduino-nano-board

Project Description:
ATmega 328 arduino nano board with 8bit analogue IN pins.5V operating voltage 7-12V input. 46mmx20mm


